# Kingdom Fabric Mod build repository

This repository builds the Fabric mod ZIP with GitHub Actions.

## Build
1. Upload the contents of this folder to the root of a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build Kingdom Fabric Mod** and run it, or push a change to the mod ZIP/workflow.
4. When the run succeeds, open the run and download the **kingdom-fabric-mod** artifact.
5. Extract the artifact and use the regular mod `.jar` (not the sources JAR) in your Fabric mods folder.

The mod targets Minecraft 1.21.11 and Java 21 according to its project configuration.
