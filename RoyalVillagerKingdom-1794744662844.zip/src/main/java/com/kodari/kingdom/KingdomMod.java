package com.kodari.kingdom;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;

public class KingdomMod implements ModInitializer {
    private static final Map<VillagerEntity, ServerPlayerEntity> FOLLOWING = new HashMap<>();
    private static final Map<VillagerEntity, Bowing> BOWING = new HashMap<>();
    private static final Queue<BuildStep> BUILD_QUEUE = new ArrayDeque<>();
    private static List<VillagerEntity> builders = List.of();
    private static ServerWorld buildWorld;
    private static ServerPlayerEntity buildingKing;
    private static boolean building;
    private static int followClock;
    private static int buildCursor;

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("king")
                        .then(CommandManager.argument("order", StringArgumentType.greedyString())
                                .executes(context -> executeOrder(context.getSource(), StringArgumentType.getString(context, "order"))))));

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickBowing();
            tickFollowing();
            tickCastleBuild();
        });
    }

    private static int executeOrder(ServerCommandSource source, String rawOrder) throws CommandSyntaxException {
        ServerPlayerEntity king = source.getPlayerOrThrow();
        if (!king.isCreative()) {
            king.sendMessage(Text.literal("The king's commands only work in Creative mode."));
            return 0;
        }

        List<VillagerEntity> villagers = king.getEntityWorld().getEntitiesByClass(
                VillagerEntity.class, king.getBoundingBox().expand(32.0), villager -> true);
        if (villagers.isEmpty()) {
            king.sendMessage(Text.literal("There are no villagers nearby to command. Get within 32 blocks of a village."));
            return 0;
        }

        String order = rawOrder.trim();
        String normalized = order.toLowerCase(Locale.ROOT);
        if ((normalized.contains("build") || normalized.contains("make")) && normalized.contains("castle")) {
            startCastleBuild(king, villagers);
        } else if (normalized.contains("follow") || normalized.contains("come with me") || normalized.contains("come here")) {
            for (VillagerEntity villager : villagers) {
                FOLLOWING.put(villager, king);
                villager.getLookControl().lookAt(king);
            }
            king.sendMessage(Text.literal("Your villagers are following you, Your Majesty. Say 'stay' to halt them."));
            speakForVillagers(king, villagers, "We follow our king!");
        } else if (normalized.contains("stay") || normalized.equals("stop") || normalized.contains("wait here")) {
            for (VillagerEntity villager : villagers) {
                FOLLOWING.remove(villager);
                EntityNavigation navigation = villager.getNavigation();
                navigation.stop();
                villager.getLookControl().lookAt(king);
            }
            king.sendMessage(Text.literal("Your villagers have stopped and await your next order."));
            speakForVillagers(king, villagers, "We shall wait here, my liege.");
        } else if (normalized.contains("bow") || normalized.contains("kneel")) {
            for (VillagerEntity villager : villagers) {
                villager.getLookControl().lookAt(king);
                Bowing bow = BOWING.computeIfAbsent(villager, ignored -> new Bowing(villager.getPitch()));
                bow.ticksRemaining = 16;
                villager.setPitch(45.0F);
            }
            king.sendMessage(Text.literal("The villagers bow before their king."));
            speakForVillagers(king, villagers, "Long live the king!");
        } else if (normalized.startsWith("say ") || normalized.startsWith("speak ") || normalized.startsWith("tell them ")) {
            String speech = speechFrom(order);
            if (speech.isBlank()) {
                king.sendMessage(Text.literal("Tell them what to say, for example: /king say Long live the king!"));
            } else {
                speakForVillagers(king, villagers, speech);
            }
        } else {
            king.sendMessage(Text.literal("Your villagers listen. Try /king follow me, /king stay, /king bow, /king build me a castle, or /king say <words>."));
            speakForVillagers(king, villagers, "We hear you, my liege. Give us an order and we shall obey.");
        }
        return 1;
    }

    private static String speechFrom(String order) {
        String normalized = order.toLowerCase(Locale.ROOT);
        if (normalized.startsWith("say ")) {
            return order.substring(4).trim();
        }
        if (normalized.startsWith("speak ")) {
            return order.substring(6).trim();
        }
        return order.substring(10).trim();
    }

    private static void speakForVillagers(ServerPlayerEntity king, List<VillagerEntity> villagers, String words) {
        int speakers = Math.min(villagers.size(), 4);
        for (int i = 0; i < speakers; i++) {
            VillagerEntity villager = villagers.get(i);
            villager.getLookControl().lookAt(king);
            king.sendMessage(Text.literal("Villager: " + words));
        }
    }

    private static void startCastleBuild(ServerPlayerEntity king, List<VillagerEntity> villagers) {
        if (building) {
            king.sendMessage(Text.literal("The villagers are already building a castle."));
            return;
        }

        BlockPos origin = king.getBlockPos().add(8, 0, 0);
        Map<BlockPos, BlockState> plan = createCastlePlan(origin);
        BUILD_QUEUE.clear();
        for (Map.Entry<BlockPos, BlockState> entry : plan.entrySet()) {
            BUILD_QUEUE.add(new BuildStep(entry.getKey(), entry.getValue()));
        }
        builders = new ArrayList<>(villagers);
        buildWorld = king.getEntityWorld();
        buildingKing = king;
        building = true;
        buildCursor = 0;

        king.sendMessage(Text.literal("Your villagers are building a stone-brick castle 8 blocks to your east. Construction is underway."));
        speakForVillagers(king, villagers, "We shall build a castle worthy of our king!");
    }

    private static Map<BlockPos, BlockState> createCastlePlan(BlockPos origin) {
        Map<BlockPos, BlockState> plan = new LinkedHashMap<>();
        for (int x = 0; x <= 16; x++) {
            for (int z = 0; z <= 16; z++) {
                place(plan, origin, x, 0, z, Blocks.STONE_BRICKS);
            }
        }

        for (int y = 1; y <= 6; y++) {
            for (int x = 0; x <= 16; x++) {
                for (int z = 0; z <= 16; z++) {
                    if (x != 0 && x != 16 && z != 0 && z != 16) {
                        continue;
                    }
                    if (z == 0 && x >= 7 && x <= 9 && y <= 2) {
                        continue;
                    }
                    Block wallBlock = (x + z + y) % 11 == 0 ? Blocks.CRACKED_STONE_BRICKS : Blocks.STONE_BRICKS;
                    place(plan, origin, x, y, z, wallBlock);
                }
            }
        }

        int[][] towers = {{0, 0}, {13, 0}, {0, 13}, {13, 13}};
        for (int[] tower : towers) {
            for (int y = 1; y <= 11; y++) {
                for (int dx = 0; dx < 4; dx++) {
                    for (int dz = 0; dz < 4; dz++) {
                        if (dx == 0 || dx == 3 || dz == 0 || dz == 3 || y == 11) {
                            Block towerBlock = (dx + dz + y) % 9 == 0 ? Blocks.CRACKED_STONE_BRICKS : Blocks.STONE_BRICKS;
                            place(plan, origin, tower[0] + dx, y, tower[1] + dz, towerBlock);
                        }
                    }
                }
            }
        }

        for (int i = 2; i <= 14; i += 2) {
            place(plan, origin, i, 7, 0, Blocks.STONE_BRICKS);
            place(plan, origin, i, 7, 16, Blocks.STONE_BRICKS);
            place(plan, origin, 0, 7, i, Blocks.STONE_BRICKS);
            place(plan, origin, 16, 7, i, Blocks.STONE_BRICKS);
        }

        for (int y = 1; y <= 5; y++) {
            for (int i = 5; i <= 11; i++) {
                if (!(i >= 7 && i <= 9 && y <= 2)) {
                    place(plan, origin, i, y, 5, Blocks.STONE_BRICKS);
                }
                place(plan, origin, i, y, 11, Blocks.STONE_BRICKS);
                place(plan, origin, 5, y, i, Blocks.STONE_BRICKS);
                place(plan, origin, 11, y, i, Blocks.STONE_BRICKS);
            }
        }
        for (int x = 5; x <= 11; x++) {
            for (int z = 5; z <= 11; z++) {
                place(plan, origin, x, 6, z, Blocks.STONE_BRICKS);
            }
        }

        place(plan, origin, 3, 1, 3, Blocks.TORCH);
        place(plan, origin, 13, 1, 3, Blocks.TORCH);
        place(plan, origin, 3, 1, 13, Blocks.TORCH);
        place(plan, origin, 13, 1, 13, Blocks.TORCH);
        for (int z = -4; z < 0; z++) {
            for (int x = 7; x <= 9; x++) {
                place(plan, origin, x, 0, z, Blocks.COBBLESTONE);
            }
        }
        return plan;
    }

    private static void place(Map<BlockPos, BlockState> plan, BlockPos origin, int x, int y, int z, Block block) {
        plan.put(origin.add(x, y, z), block.getDefaultState());
    }

    private static void tickBowing() {
        Iterator<Map.Entry<VillagerEntity, Bowing>> iterator = BOWING.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<VillagerEntity, Bowing> entry = iterator.next();
            VillagerEntity villager = entry.getKey();
            Bowing bow = entry.getValue();
            if (villager.isRemoved() || --bow.ticksRemaining <= 0) {
                if (!villager.isRemoved()) {
                    villager.setPitch(bow.originalPitch);
                }
                iterator.remove();
            }
        }
    }

    private static void tickFollowing() {
        if (++followClock < 10) {
            return;
        }
        followClock = 0;
        Iterator<Map.Entry<VillagerEntity, ServerPlayerEntity>> iterator = FOLLOWING.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<VillagerEntity, ServerPlayerEntity> entry = iterator.next();
            VillagerEntity villager = entry.getKey();
            ServerPlayerEntity king = entry.getValue();
            if (villager.isRemoved() || king.isRemoved()) {
                iterator.remove();
            } else {
                villager.getNavigation().startMovingTo(king, 1.0);
            }
        }
    }

    private static void tickCastleBuild() {
        if (!building) {
            return;
        }
        for (int i = 0; i < 8 && !BUILD_QUEUE.isEmpty(); i++) {
            BuildStep step = BUILD_QUEUE.remove();
            buildWorld.setBlockState(step.position(), step.state());
            if (!builders.isEmpty()) {
                VillagerEntity builder = builders.get(buildCursor++ % builders.size());
                if (!builder.isRemoved()) {
                    builder.getLookControl().lookAt(
                            step.position().getX() + 0.5,
                            step.position().getY() + 0.5,
                            step.position().getZ() + 0.5,
                            30.0F,
                            30.0F);
                }
            }
        }
        if (BUILD_QUEUE.isEmpty()) {
            if (buildingKing != null && !buildingKing.isRemoved()) {
                buildingKing.sendMessage(Text.literal("The castle is complete, Your Majesty!"));
            }
            builders = List.of();
            buildWorld = null;
            buildingKing = null;
            building = false;
        }
    }

    private static final class Bowing {
        private final float originalPitch;
        private int ticksRemaining;

        private Bowing(float originalPitch) {
            this.originalPitch = originalPitch;
        }
    }

    private record BuildStep(BlockPos position, BlockState state) {
    }
}